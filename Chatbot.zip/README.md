# 🤖 Chatbot - CodeAlpha

Rule-based chatbot with CustomTkinter.
